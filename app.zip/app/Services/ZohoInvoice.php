<?php

namespace App\Services;




use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Cache;
use GuzzleHttp\Cookie\CookieJar;
use App\Models\ApiToken;
use GuzzleHttp\Client;
use Illuminate\Http\Request;

class ZohoInvoice
{

    protected $clientID;
    protected $clientSecret;
    protected $redirectUri;
    protected $refreshToken;
    protected $scope;
    protected $orgId;

    public function __construct()
    {
        $this->scope = config('services.zoho.scope');
        $this->clientID = config('services.zoho.client_id');
        $this->clientSecret = config('services.zoho.client_secret');
        $this->redirectUri = config('services.zoho.redirect_uri');
        $this->orgId = config('services.zoho.org_id');
        $this->refreshToken = "1000.4f137b39002c78113a04602a1e77ab26.e8c266a2a304861e19a5b79aee2d00b9";
    }

    public function getAccessToken()
    {
        $client = new Client();
        $response = $client->post('https://accounts.zoho.com/oauth/v2/token', [
            'verify' => false,
            'form_params' => [
                'refresh_token' => $this->refreshToken,
                'client_id' => $this->clientID,
                'client_secret' => $this->clientSecret,
                'grant_type' => 'refresh_token',
            ]
        ]);
        $data = json_decode($response->getBody(), true);
        return $data['access_token'];
    }

    public function createInvoice($notes, $currency_code, $lineitems)
    {
        $accessToken = $this->getAccessToken();
        $client = new Client();
        $response = $client->post('https://www.zohoapis.com/invoice/v3/invoices?organization_id=' . $this->orgId, [
            'verify' => false,
            'headers' => [
            'Authorization' => 'Zoho-oauthtoken ' .$accessToken,
            'Content-Type'  => 'application/json',
            ],
            'json' => [
                'customer_id' => 6374281000000095007,
                'notes' => $notes,
                'currency_code' => $currency_code,
                'line_items' => $lineitems
            ]
        ]);
        // return response()->json(json_decode($response->getBody(), true));
        return json_decode($response->getBody(), true);
    }






// public function index(){
    //     $url = 'https://accounts.zoho.com/oauth/v2/auth?' . http_build_query([
    //         'scope'         => $this->scope,
    //         'client_id'     => $this->clientID,
    //         'state'         => 'testing',
    //         'response_type' => 'code',
    //         'redirect_uri'  => $this->redirectUri,
    //         'access_type'   => 'offline',
    //     ]);

    //     return redirect()->away($url);

    // }

    // public function redirectToZoho(Request $request)
    // {
    //     $code= $request->code;
    //     return view('Api.zohoapi', compact('code'));
    // }

    // public function getRefreshAndAccessToken(Request $request)
    // {
    //     $code= $request->code;
    //     $response = Http::withOptions(['verify' => false])->asForm()->post('https://accounts.zoho.com/oauth/v2/token', [
    //         'code' => $code,
    //         'client_id' => '1000.GN0KHG7RG4BNRL3B3OT9C2U2K62R7V',
    //         'client_secret' => '00c794da6681c7bbd82fd6be748dabb218450349a1',
    //         'redirect_uri' => 'http://localhost:8000/zoho/callback',
    //         'grant_type' => 'authorization_code',
    //     ]);

    //     $data = $response->json();

    //     if (isset($data['refresh_token'])) {
    //         ApiToken::updateOrCreate(
    //             ['zoho_refresh_token' => $data['refresh_token']],
    //         );
    //     }

    //     return response()->json($data);
    //     // dd($response->json());
    // }

    // $response = Http::withOptions(['verify' => false])->asForm()->post('https://accounts.zoho.com/oauth/v2/token', [
    //     'refresh_token' => $this->refreshToken,
    //     'client_id' => $this->clientID,
    //     'client_secret' => $this->clientSecret,
    //     'redirect_uri' => $this->redirectUri,
    //     'grant_type' => 'refresh_token',
    //     ]);
// return $response->json();

}
